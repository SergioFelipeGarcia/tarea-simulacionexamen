(
    id       int     null,
    correo   varchar(50) null,
    password varchar(200) null invisible,
    constraint colaboradores_pk
    primary key (id)
);

create table pedidos
(
    id           int     null,
    fecha_pedido date    null,
    producto     varchar(50) null,
    unidades     int     null,
    constraint pedidos_pk
        primary key (id)
);
