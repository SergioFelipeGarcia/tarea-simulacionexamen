<?php
include("header.html");

?>
<h2>Pagina index</h2>



<?php
include("footer.html");

?>
