<?php
include("header.html");
require("config.php");
echo"<h2>eliminar</h2>";

if(isset($_GET['codigo'])){
    require_once "config.php";

    foreach($conn->query('SELECT * from pedidos where id='.$_GET['codigo'].'') as $row){
        echo'<div class="card" style="width: 18rem;">';
        echo '<div class="card-body">';
        echo '<p class="card-title">'.$row["producto"].'</p>';
        echo '<p class="card-text">'.$row["fecha_pedido"].'</p>';
        echo '<p class="card-text">'.$row["unidades"].'</p>';
        echo '<p class="card-text">'.$row["id"].'</p>';


        echo'</div>';
        echo'</div>';
    }
}
?>

<?php
require_once "config.php";

if(isset($_POST['eliminar']) && isset($_POST['id']) && is_numeric($_POST['id'])){
    $id = $_POST['id'];

    $sql = "DELETE FROM pedidos WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();

    echo "El registro ha sido eliminado exitosamente.";
    header("Location: consultar.php");
    exit();

}
?>
<form action="eliminar.php" method="post">
  <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
  <button type="submit" name="eliminar" class="btn btn-danger">Eliminar definitivamente</button>
</form>
<?php
include("footer.html");
?>
