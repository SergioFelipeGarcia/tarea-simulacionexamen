<?php
include("header.html");

?>
    <h2>logout</h2>



<?php
include("footer.html");

?>