<?php
include "header.html";
echo "<h2>Listado de pedidos</h2>";
require("config.php")
?>
<table class="table table-dark">
    <thead>
    <tr>
        <th scope="col">ID</th>
        <th scope="col">Fecha Pedido</th>
        <th scope="col">Producto</th>
        <th scope="col">Unidades</th>
        <th scope="col">Editar</th>
    </tr>
    <?php
    try {
        require_once "config.php";

        foreach($conn->query('SELECT * from pedidos') as $row) {
            echo "<tr>".
                "<td>".$row["id"]."</td>".
                "<td>".$row["fecha_pedido"]."</td>".
                "<td>".$row["producto"]."</td>".
                "<td>".$row["unidades"]."</td>".
                "<td><a href='eliminar.php?codigo=".$row["id"]."' ><ion-icon name='trash-bin-outline'></ion-icon></a></td></tr>";
        }
        $conn = null;
    } catch (PDOException $e) {
        print "Error!: " . $e->getMessage() . "<br/>";
        die();
    }
    ?>
</table>

<?php
require_once "config.php";

if(isset($_POST['eliminar']) && isset($_POST['id']) && is_numeric($_POST['id'])){
    $id = $_POST['id'];

    $sql = "DELETE FROM pedidos WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();

    echo "El registro ha sido eliminado exitosamente.";
} else {
    echo "No se pudo eliminar el registro. El ID no es válido.";
}
?>
<form action="eliminar.php" method="post">
    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
    <button type="submit" name="eliminar" class="btn btn-danger">Eliminar definitivamente</button>
</form>

<?php
include "footer.html";


?>

